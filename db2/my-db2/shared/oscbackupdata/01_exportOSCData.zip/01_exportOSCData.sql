
export to OSC.OSC_SERVICE_ENDPOINT.ixf of ixf messages export_ixf_osc_service_endpoint.log select NAME, URL_ENDPOINT from OSC.OSC_SERVICE_ENDPOINT;
export to OSC.MAIN_PROD_CODE.ixf of ixf messages export_ixf_main_prod_code.log select * from OSC.MAIN_PROD_CODE;
export to OSC.OSC_EFORM.ixf of ixf messages export_ixf_eform.log select * from OSC.OSC_EFORM;
export to OSC.OSC_EFORM_MAPPING.ixf of ixf messages export_ixf_eform_mapping.log select * from OSC.OSC_EFORM_MAPPING;
export to OSC.OSC_EFORM_GROUP.ixf of ixf messages export_ixf_eform_group.log select * from OSC.OSC_EFORM_GROUP;
export to OSC.MAIN_FEE.ixf of ixf messages export_ixf_main_fee.log select * from OSC.MAIN_FEE;
